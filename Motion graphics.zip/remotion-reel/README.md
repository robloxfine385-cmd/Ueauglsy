# remotion-reel — Apple glassmorphism, 1080×1920, zero external assets

```
npm install
npm run studio     # preview, port 3000
npm run render     # out/video.mp4
```

- Script + beats: `src/script.ts`
- Background: CSS linear gradient + solid-color blurred blobs (`src/components/Layers.tsx`)
- SFX: 4 small WAVs in `public/sfx` (regenerate with `npm run sfx`, or set `SFX_ENABLED = false`)
