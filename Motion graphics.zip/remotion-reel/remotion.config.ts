import { Config } from "@remotion/cli/config";

Config.setVideoImageFormat("jpeg");
Config.setCodec("h264");
Config.setCrf(18);
Config.setOverwriteOutput(true);
// Replit machines are small: keep Chrome tabs low, give slow frames more time.
Config.setConcurrency(2);
Config.setDelayRenderTimeoutInMilliseconds(120000);
