// Deterministic, original, copyright-free SFX synthesized from math → public/sfx/*.wav
import { mkdirSync, writeFileSync } from "node:fs";

const SR = 44100;
mkdirSync("public/sfx", { recursive: true });

const mulberry32 = (a) => () => {
  let t = (a += 0x6d2b79f5);
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

const toWav = (samples) => {
  let peak = 0;
  for (const s of samples) peak = Math.max(peak, Math.abs(s));
  const gain = peak > 0 ? 0.85 / peak : 1;
  const n = samples.length;
  const buf = Buffer.alloc(44 + n * 2);
  buf.write("RIFF", 0);
  buf.writeUInt32LE(36 + n * 2, 4);
  buf.write("WAVE", 8);
  buf.write("fmt ", 12);
  buf.writeUInt32LE(16, 16);
  buf.writeUInt16LE(1, 20);
  buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(SR, 24);
  buf.writeUInt32LE(SR * 2, 28);
  buf.writeUInt16LE(2, 32);
  buf.writeUInt16LE(16, 34);
  buf.write("data", 36);
  buf.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) {
    const v = Math.max(-1, Math.min(1, samples[i] * gain));
    buf.writeInt16LE(Math.round(v * 32767), 44 + i * 2);
  }
  return buf;
};

const whoosh = () => {
  const n = Math.floor(SR * 0.6);
  const rnd = mulberry32(11);
  const out = new Float32Array(n);
  let lp1 = 0;
  let lp2 = 0;
  for (let i = 0; i < n; i++) {
    const t = i / n;
    const fc = 300 + 5200 * Math.pow(Math.sin(Math.PI * Math.min(1, t * 1.15)), 2);
    const a = 1 - Math.exp((-2 * Math.PI * fc) / SR);
    const x = rnd() * 2 - 1;
    lp1 += a * (x - lp1);
    lp2 += a * (lp1 - lp2);
    out[i] = lp2 * Math.pow(Math.sin(Math.PI * t), 1.6);
  }
  return out;
};

const pop = () => {
  const n = Math.floor(SR * 0.22);
  const out = new Float32Array(n);
  let phase = 0;
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    phase += (2 * Math.PI * (160 + 420 * Math.exp(-t * 28))) / SR;
    out[i] = Math.sin(phase) * Math.exp(-t * 20);
  }
  return out;
};

const thump = () => {
  const n = Math.floor(SR * 0.55);
  const rnd = mulberry32(23);
  const out = new Float32Array(n);
  let phase = 0;
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    phase += (2 * Math.PI * (42 + 80 * Math.exp(-t * 14))) / SR;
    out[i] = Math.sin(phase) * Math.exp(-t * 7) + (rnd() * 2 - 1) * 0.15 * Math.exp(-t * 90);
  }
  return out;
};

const tick = () => {
  const n = Math.floor(SR * 0.06);
  const rnd = mulberry32(37);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    out[i] = (Math.sin(2 * Math.PI * 2600 * t) * 0.8 + (rnd() * 2 - 1) * 0.2) * Math.exp(-t * 160);
  }
  return out;
};

const kit = { whoosh, pop, thump, tick };
for (const [name, fn] of Object.entries(kit)) {
  writeFileSync(`public/sfx/${name}.wav`, toWav(fn()));
  console.log(`public/sfx/${name}.wav`);
}
