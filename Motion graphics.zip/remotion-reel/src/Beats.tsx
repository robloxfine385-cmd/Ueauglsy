import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { Entrance, Glass, clamp, toBn, useBreathe, useExit } from "./components/Motion";
import { L, LIST_ITEM_DELAY, LIST_ITEM_STEP } from "./config";
import type { Beat } from "./script";
import { theme } from "./theme";

type Of<T extends Beat["type"]> = Extract<Beat, { type: T }>;

// Shrinks long Bengali strings so they stay inside the zone.
const fit = (text: string) => {
  const n = [...text].length;
  return n <= 8 ? 1 : n <= 14 ? 0.85 : n <= 26 ? 0.7 : 0.58;
};

/** Positions beat content inside the layout's graphics zone and handles the exit. */
const Zone: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const exit = useExit(10);
  return (
    <AbsoluteFill>
      <div
        style={{
          position: "absolute",
          left: 60,
          right: 60,
          top: L.zone.y,
          height: L.zone.h,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          textAlign: "center",
          opacity: exit.opacity,
          transform: `translateY(${exit.y}px) scale(${exit.scale})`,
        }}
      >
        {children}
      </div>
    </AbsoluteFill>
  );
};

/** Light streak that whips across the zone at every beat start (transition accent). */
const Sweep: React.FC = () => {
  const frame = useCurrentFrame();
  const x = interpolate(frame, [0, 12], [-900, 1300], { easing: theme.ease.out, ...clamp });
  const o = interpolate(frame, [0, 3, 12], [0, 0.9, 0], clamp);
  return (
    <AbsoluteFill style={{ pointerEvents: "none", overflow: "hidden" }}>
      <div
        style={{
          position: "absolute",
          top: L.zone.y - 16,
          left: 0,
          width: 700,
          height: 4,
          borderRadius: 4,
          opacity: o,
          transform: `translateX(${x}px)`,
          background: `linear-gradient(90deg, transparent, ${theme.colors.text}, transparent)`,
        }}
      />
    </AbsoluteFill>
  );
};

const Hook: React.FC<{ b: Of<"hook"> }> = ({ b }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const words = b.title.split(/\s+/).filter(Boolean);
  const hl = b.highlight ?? words.length - 1;
  const size = 96 * L.fs * fit(b.title);
  const landed = words.length * 3 + 8;
  const bar = spring({ frame: frame - landed, fps, config: theme.spring.smooth });

  return (
    <Zone>
      <Entrance from={36}>
        <Glass radius={56} padding={`${34 * L.fs}px ${46 * L.fs}px`}>
          <div
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "center",
              columnGap: 22 * L.fs,
              rowGap: 4,
              fontSize: size,
              fontWeight: 800,
              lineHeight: theme.type.lineHeight,
              color: theme.colors.text,
            }}
          >
            {words.map((w, i) => {
              const p = spring({ frame: frame - i * 3, fps, config: theme.spring.snappy });
              const isHl = i === hl;
              return (
                <span
                  key={i}
                  style={{
                    position: "relative",
                    display: "inline-block",
                    opacity: Math.min(1, p * 1.5),
                    transform: `translateY(${interpolate(p, [0, 1], [34, 0])}px) scale(${interpolate(p, [0, 1], [0.92, 1])})`,
                    color: isHl ? theme.colors.primary : theme.colors.text,
                    textShadow: isHl ? `0 0 40px ${theme.colors.glow}` : `0 4px 24px ${theme.colors.shadow}`,
                  }}
                >
                  {w}
                  {isHl ? (
                    <span
                      style={{
                        position: "absolute",
                        left: 0,
                        right: 0,
                        bottom: size * 0.03,
                        height: Math.max(6, size * 0.06),
                        borderRadius: 8,
                        background: theme.colors.primary,
                        transformOrigin: "left center",
                        transform: `scaleX(${Math.min(1, bar)})`,
                      }}
                    />
                  ) : null}
                </span>
              );
            })}
          </div>
        </Glass>
      </Entrance>
      {b.sub ? (
        <Entrance delay={landed + 2} from={24} style={{ marginTop: 22 * L.fs }}>
          <Glass radius={999} padding={`${12 * L.fs}px ${34 * L.fs}px`} tone="dark" shine={landed + 4}>
            <span style={{ fontSize: 36 * L.fs, fontWeight: 600, color: theme.colors.text, lineHeight: theme.type.lineHeight }}>
              {b.sub}
            </span>
          </Glass>
        </Entrance>
      ) : null}
    </Zone>
  );
};

const Keyword: React.FC<{ b: Of<"keyword"> }> = ({ b }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const pop = spring({ frame, fps, config: theme.spring.bouncy });
  const breathe = useBreathe(0.018, 18);
  const size = 150 * L.fs * fit(b.word);
  const underline = spring({ frame: frame - 10, fps, config: theme.spring.smooth });

  const ring = (delay: number) => {
    const t = interpolate(frame, [delay, delay + 22], [0, 1], { easing: theme.ease.out, ...clamp });
    const w = (300 + 560 * t) * L.fs;
    const h = (150 + 260 * t) * L.fs;
    return (
      <div
        key={delay}
        style={{
          position: "absolute",
          left: "50%",
          top: "50%",
          width: w,
          height: h,
          marginLeft: -w / 2,
          marginTop: -h / 2,
          borderRadius: 999,
          border: `3px solid ${theme.colors.primary}`,
          opacity: 0.5 * (1 - t),
        }}
      />
    );
  };

  return (
    <Zone>
      <div style={{ position: "relative", display: "flex", flexDirection: "column", alignItems: "center" }}>
        {ring(0)}
        {ring(5)}
        {b.label ? (
          <Entrance from={20} style={{ marginBottom: 18 * L.fs }}>
            <Glass radius={999} padding={`${8 * L.fs}px ${28 * L.fs}px`} tone="dark" shine={4}>
              <span style={{ fontSize: 32 * L.fs, fontWeight: 700, color: theme.colors.accent, lineHeight: theme.type.lineHeight }}>
                {b.label}
              </span>
            </Glass>
          </Entrance>
        ) : null}
        <div style={{ opacity: Math.min(1, pop * 2), transform: `scale(${Math.max(0, pop) * breathe})` }}>
          <Glass radius={80 * L.fs} padding={`${12 * L.fs}px ${64 * L.fs}px ${22 * L.fs}px`}>
            <div
              style={{
                fontSize: size,
                fontWeight: 800,
                lineHeight: theme.type.lineHeight,
                color: theme.colors.primary,
                textShadow: `0 0 48px ${theme.colors.glow}`,
              }}
            >
              {b.word}
            </div>
            <div
              style={{
                margin: "0 auto",
                width: "60%",
                height: 8 * L.fs,
                borderRadius: 999,
                background: `linear-gradient(90deg, ${theme.colors.blue}, ${theme.colors.primary})`,
                transformOrigin: "center",
                transform: `scaleX(${Math.min(1, underline)})`,
              }}
            />
          </Glass>
        </div>
      </div>
    </Zone>
  );
};

const Stat: React.FC<{ b: Of<"stat"> }> = ({ b }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = spring({ frame: frame - 6, fps, config: { damping: 30, stiffness: 60, mass: 1 } });
  const val = interpolate(t, [0, 1], [0, b.value]);
  let str = val.toFixed(b.decimals ?? 0);
  if (b.numerals === "bn") str = toBn(str);
  const fill = Math.min(100, b.fill ?? 100) * Math.min(1, spring({ frame: frame - 8, fps, config: theme.spring.smooth }));
  const small = 80 * L.fs;

  return (
    <Zone>
      <Entrance from={36}>
        <Glass radius={56} padding={`${30 * L.fs}px ${56 * L.fs}px`} style={{ width: Math.min(900, 820 * L.fs) }}>
          <div
            style={{
              display: "flex",
              alignItems: "baseline",
              justifyContent: "center",
              columnGap: 10 * L.fs,
              color: theme.colors.primary,
              fontWeight: 800,
              lineHeight: 1.15,
              textShadow: `0 0 48px ${theme.colors.glow}`,
            }}
          >
            {b.prefix ? <span style={{ fontSize: small }}>{b.prefix}</span> : null}
            <span style={{ fontSize: 170 * L.fs, fontVariantNumeric: "tabular-nums" }}>{str}</span>
            {b.suffix ? <span style={{ fontSize: small }}>{b.suffix}</span> : null}
          </div>
          <div style={{ marginTop: 6 * L.fs, fontSize: 42 * L.fs, fontWeight: 600, color: theme.colors.text, lineHeight: theme.type.lineHeight }}>
            {b.label}
          </div>
          <div
            style={{
              marginTop: 26 * L.fs,
              height: 18 * L.fs,
              borderRadius: 999,
              overflow: "hidden",
              background: theme.colors.track,
            }}
          >
            <div
              style={{
                width: `${fill}%`,
                height: "100%",
                borderRadius: 999,
                background: `linear-gradient(90deg, ${theme.colors.blue}, ${theme.colors.primary})`,
              }}
            />
          </div>
        </Glass>
      </Entrance>
    </Zone>
  );
};

const List: React.FC<{ b: Of<"list"> }> = ({ b }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const items = b.items.slice(0, 4);
  const k = items.length > 3 ? 0.88 : 1;
  const s = L.fs * k;

  return (
    <Zone>
      {b.title ? (
        <Entrance from={20} style={{ marginBottom: 14 * L.fs }}>
          <div style={{ fontSize: 36 * s, fontWeight: 700, color: theme.colors.textDim, lineHeight: theme.type.lineHeight }}>
            {b.title}
          </div>
        </Entrance>
      ) : null}
      <Entrance from={30}>
        <Glass radius={48} padding={0} style={{ width: Math.min(920, 880 * L.fs) }}>
          {items.map((item, i) => {
            const d = LIST_ITEM_DELAY + i * LIST_ITEM_STEP;
            const p = spring({ frame: frame - d, fps, config: theme.spring.snappy });
            const check = spring({ frame: frame - d - 4, fps, config: theme.spring.bouncy });
            const edge = `${6 * s}px solid ${theme.colors.text}`;
            return (
              <div
                key={i}
                style={{
                  display: "flex",
                  alignItems: "center",
                  columnGap: 26 * s,
                  padding: `${18 * s}px ${30 * s}px`,
                  borderTop: i === 0 ? "none" : `1.5px solid ${theme.colors.glassBorder}`,
                  opacity: Math.min(1, p * 1.5),
                  transform: `translateX(${interpolate(p, [0, 1], [-40, 0])}px)`,
                }}
              >
                <div
                  style={{
                    width: 64 * s,
                    height: 64 * s,
                    flexShrink: 0,
                    borderRadius: 18 * s,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    background: `linear-gradient(135deg, ${theme.colors.blue}, ${theme.colors.purple})`,
                  }}
                >
                  <div
                    style={{
                      width: 16 * s,
                      height: 30 * s,
                      borderRight: edge,
                      borderBottom: edge,
                      borderRadius: 3,
                      transform: `translateY(-3px) rotate(45deg) scale(${Math.max(0, Math.min(1.1, check))})`,
                    }}
                  />
                </div>
                <span
                  style={{
                    fontSize: 50 * s,
                    fontWeight: 700,
                    color: theme.colors.text,
                    textAlign: "left",
                    lineHeight: theme.type.lineHeight,
                  }}
                >
                  {item}
                </span>
              </div>
            );
          })}
        </Glass>
      </Entrance>
    </Zone>
  );
};

const Cta: React.FC<{ b: Of<"cta"> }> = ({ b }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const pulse = (Math.sin(frame / 12) + 1) / 2;
  const p = spring({ frame: frame - 10, fps, config: theme.spring.bouncy });
  const ink = `${6 * L.fs}px solid ${theme.colors.bg}`;

  return (
    <Zone>
      <Entrance from={30}>
        <div
          style={{
            fontSize: 88 * L.fs * fit(b.title),
            fontWeight: 800,
            lineHeight: theme.type.lineHeight,
            color: theme.colors.text,
            textShadow: `0 6px 30px ${theme.colors.shadow}`,
          }}
        >
          {b.title}
        </div>
      </Entrance>
      <div
        style={{
          marginTop: 34 * L.fs,
          opacity: Math.min(1, p * 1.4),
          transform: `scale(${interpolate(p, [0, 1], [0.7, 1]) * (1 + pulse * 0.02)})`,
        }}
      >
        <Glass
          radius={999}
          padding={`${22 * L.fs}px ${64 * L.fs}px`}
          shine={14}
          style={{
            background: `linear-gradient(180deg, ${theme.colors.primaryHi}, ${theme.colors.blue})`,
            boxShadow: `0 0 ${40 + 30 * pulse}px ${theme.colors.glow}, inset 0 1.5px 0 ${theme.colors.glassEdge}`,
          }}
        >
          <div style={{ display: "flex", alignItems: "center", columnGap: 22 * L.fs }}>
            <span style={{ fontSize: 54 * L.fs, fontWeight: 800, color: theme.colors.bg, lineHeight: theme.type.lineHeight }}>
              {b.button}
            </span>
            <div
              style={{
                width: 20 * L.fs,
                height: 20 * L.fs,
                borderTop: ink,
                borderRight: ink,
                borderRadius: 3,
                transform: "rotate(45deg)",
              }}
            />
          </div>
        </Glass>
      </div>
    </Zone>
  );
};

export const BeatView: React.FC<{ beat: Beat }> = ({ beat }) => (
  <>
    <Sweep />
    {beat.type === "hook" && <Hook b={beat} />}
    {beat.type === "keyword" && <Keyword b={beat} />}
    {beat.type === "stat" && <Stat b={beat} />}
    {beat.type === "list" && <List b={beat} />}
    {beat.type === "cta" && <Cta b={beat} />}
  </>
);
