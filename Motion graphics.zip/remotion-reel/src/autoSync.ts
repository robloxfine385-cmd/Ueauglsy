export type Line = { start: number; end: number; text: string };

/**
 * Spreads lines across [start, end] proportional to text length, then snaps each
 * boundary to the nearest measured pause (within `snap` seconds).
 */
export const autoSync = (
  lines: string[],
  opts: { start: number; end: number; pauses: number[]; snap?: number; minLen?: number },
): Line[] => {
  const { start, end, pauses, snap = 1.6, minLen = 1.2 } = opts;
  const weights = lines.map((t) => Math.max(1, [...t.replace(/\s+/g, "")].length));
  const total = weights.reduce((a, b) => a + b, 0);

  const bounds: number[] = [start];
  let acc = 0;
  for (let i = 0; i < lines.length - 1; i++) {
    acc += weights[i];
    const ideal = start + (end - start) * (acc / total);
    let best = ideal;
    let bestD = snap;
    for (const p of pauses) {
      const d = Math.abs(p - ideal);
      if (d < bestD) {
        best = p;
        bestD = d;
      }
    }
    const prev = bounds[bounds.length - 1];
    bounds.push(Math.min(end - 0.5, Math.max(best, prev + minLen)));
  }
  bounds.push(end);

  return lines.map((text, i) => ({
    text,
    start: bounds[i],
    end: Math.max(bounds[i] + 0.4, bounds[i + 1] - 0.05),
  }));
};
