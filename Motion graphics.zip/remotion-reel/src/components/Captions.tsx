import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { FPS, L } from "../config";
import { LINES } from "../script";
import { theme } from "../theme";
import { Glass } from "./Motion";

type Word = { text: string; s: number; e: number };
type Page = { s: number; e: number; words: Word[] };

const MAX_WORDS = 4;

// Word timing inside each line is proportional to word length (frames).
const buildPages = (): Page[] => {
  const pages: Page[] = [];
  for (const line of LINES) {
    const words = line.text.split(/\s+/).filter(Boolean);
    if (words.length === 0) continue;
    const w = words.map((x) => [...x].length + 1);
    const total = w.reduce((a, b) => a + b, 0);
    const s0 = line.start * FPS;
    const dur = (line.end - line.start) * FPS;
    let acc = 0;
    const timed: Word[] = words.map((text, i) => {
      const s = s0 + (dur * acc) / total;
      acc += w[i];
      return { text, s, e: s0 + (dur * acc) / total };
    });
    for (let i = 0; i < timed.length; i += MAX_WORDS) {
      const chunk = timed.slice(i, i + MAX_WORDS);
      pages.push({ s: chunk[0].s, e: chunk[chunk.length - 1].e, words: chunk });
    }
  }
  return pages;
};

const PAGES = buildPages();

export const Captions: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  let page: Page | null = null;
  for (let i = PAGES.length - 1; i >= 0; i--) {
    if (frame >= PAGES[i].s && frame < PAGES[i].e + 4) {
      page = PAGES[i];
      break;
    }
  }
  if (!page) return null;

  const enter = spring({ frame: frame - page.s, fps, config: theme.spring.snappy });

  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      <div
        style={{
          position: "absolute",
          left: 40,
          right: 40,
          top: L.captionY,
          display: "flex",
          justifyContent: "center",
          opacity: Math.min(1, enter * 1.6),
          transform: `translateY(-50%) translateY(${interpolate(enter, [0, 1], [24, 0])}px)`,
        }}
      >
        <Glass radius={40} padding="16px 36px" tone="dark" shine={2}>
          <div
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "center",
              columnGap: 18,
              rowGap: 2,
            }}
          >
            {page.words.map((w, i) => {
              const active = frame >= w.s && frame < w.e;
              const wp = spring({ frame: frame - w.s, fps, config: theme.spring.snappy });
              return (
                <span
                  key={i}
                  style={{
                    display: "inline-block",
                    fontSize: 64,
                    fontWeight: 800,
                    lineHeight: theme.type.lineHeight,
                    color: active ? theme.colors.accent : theme.colors.text,
                    transform: `scale(${active ? 1 + 0.06 * Math.min(1, wp) : 1})`,
                    textShadow: `0 4px 18px ${theme.colors.shadow}`,
                  }}
                >
                  {w.text}
                </span>
              );
            })}
          </div>
        </Glass>
      </div>
    </AbsoluteFill>
  );
};
