import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";

export const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

export const sec = (s: number, fps: number) => Math.round(s * fps);

export const toBn = (s: string) => s.replace(/[0-9]/g, (d) => "০১২৩৪৫৬৭৮৯"[Number(d)]);

/** fade + rise + scale, spring driven */
export const Entrance: React.FC<{
  delay?: number;
  from?: number;
  style?: React.CSSProperties;
  children: React.ReactNode;
}> = ({ delay = 0, from = 40, style, children }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config: theme.spring.smooth });
  return (
    <div
      style={{
        opacity: Math.min(1, p * 1.4),
        transform: `translateY(${interpolate(p, [0, 1], [from, 0])}px) scale(${interpolate(p, [0, 1], [0.94, 1])})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/** exit values for the last `len` frames of the enclosing Sequence (faster than entrances) */
export const useExit = (len = 10) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const start = Math.max(1, durationInFrames - len);
  const end = Math.max(start + 1, durationInFrames - 1);
  const t = interpolate(frame, [start, end], [0, 1], { easing: theme.ease.in, ...clamp });
  return { opacity: 1 - t, y: -36 * t, scale: 1 - 0.04 * t };
};

export const useBreathe = (amp = 0.015, period = 22) => {
  const frame = useCurrentFrame();
  return 1 + Math.sin(frame / period) * amp;
};

/** Apple-style frosted glass panel. Linear gradients + blur only. */
export const Glass: React.FC<{
  radius?: number;
  padding?: string | number;
  tone?: "light" | "dark";
  shine?: number; // frame (local) at which the sheen sweeps across
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({ radius = 44, padding = "30px 44px", tone = "light", shine = 6, style, children }) => {
  const frame = useCurrentFrame();
  const sx = interpolate(frame, [shine, shine + 26], [-60, 160], { easing: theme.ease.out, ...clamp });
  const so = interpolate(frame, [shine, shine + 4, shine + 26], [0, 1, 0], clamp);
  const fill =
    tone === "dark"
      ? `linear-gradient(135deg, ${theme.colors.glassDarkHi}, ${theme.colors.glassDarkLo})`
      : `linear-gradient(135deg, ${theme.colors.glassHi}, ${theme.colors.glassLo})`;
  return (
    <div
      style={{
        position: "relative",
        overflow: "hidden",
        borderRadius: radius,
        padding,
        background: fill,
        backdropFilter: theme.glassBlur,
        WebkitBackdropFilter: theme.glassBlur,
        border: `1.5px solid ${theme.colors.glassBorder}`,
        boxShadow: `0 28px 60px -18px ${theme.colors.shadow}, inset 0 1.5px 0 ${theme.colors.glassEdge}`,
        ...style,
      }}
    >
      <div
        style={{
          position: "absolute",
          top: 0,
          bottom: 0,
          left: `${sx}%`,
          width: "38%",
          opacity: so,
          background: `linear-gradient(105deg, transparent, ${theme.colors.glassSheen}, transparent)`,
          pointerEvents: "none",
        }}
      />
      {children}
    </div>
  );
};
