import React from "react";
import { Html5Audio, Sequence, staticFile, useVideoConfig } from "remotion";
import { LIST_ITEM_DELAY, LIST_ITEM_STEP, SFX_ENABLED } from "../config";
import { BEATS } from "../script";
import { sec } from "./Motion";

const LEN = { whoosh: 0.6, pop: 0.25, thump: 0.55, tick: 0.1 } as const;
type Name = keyof typeof LEN;

const Hit: React.FC<{ at: number; name: Name; volume: number }> = ({ at, name, volume }) => {
  const { fps } = useVideoConfig();
  return (
    <Sequence from={Math.max(0, at)} durationInFrames={Math.round(LEN[name] * fps)} layout="none">
      <Html5Audio src={staticFile(`sfx/${name}.wav`)} volume={volume} />
    </Sequence>
  );
};

// Subtle, synthesized SFX. Every hit starts 3 frames BEFORE the visual lands.
export const Sfx: React.FC = () => {
  const { fps } = useVideoConfig();
  if (!SFX_ENABLED) return null;

  const hits: React.ReactNode[] = [];
  BEATS.forEach((b, bi) => {
    const f = sec(b.start, fps);
    const k = (s: string) => `${bi}-${s}`;
    hits.push(<Hit key={k("w")} at={f - 3} name="whoosh" volume={0.26} />);
    if (b.type === "hook" || b.type === "cta") {
      hits.push(<Hit key={k("t")} at={f} name="thump" volume={0.3} />);
    }
    if (b.type === "keyword") {
      hits.push(<Hit key={k("p")} at={f + 2} name="pop" volume={0.32} />);
    }
    if (b.type === "stat") {
      hits.push(<Hit key={k("p")} at={f + 3} name="pop" volume={0.3} />);
      for (let i = 0; i < 8; i++) {
        hits.push(<Hit key={k(`k${i}`)} at={f + 6 + i * 3} name="tick" volume={0.1} />);
      }
    }
    if (b.type === "list") {
      b.items.slice(0, 4).forEach((_, i) => {
        hits.push(<Hit key={k(`i${i}`)} at={f + LIST_ITEM_DELAY - 3 + i * LIST_ITEM_STEP} name="pop" volume={0.26} />);
      });
    }
  });
  return <>{hits}</>;
};
