export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;

export const DURATION_SECONDS = 72.5;
export const DURATION_FRAMES = Math.floor(DURATION_SECONDS * FPS);

// Uses the 4 small WAVs already shipped in public/sfx. Set false for a fully silent, zero-asset render.
export const SFX_ENABLED = true;

// List-beat timing shared with the SFX track (frames, local to the beat)
export const LIST_ITEM_DELAY = 10;
export const LIST_ITEM_STEP = 6;

// 9:16 safe area: keep everything between y≈170 and y≈1560 (platform UI covers top/bottom).
export const L = {
  zone: { y: 330, h: 900 }, // where beat graphics live
  captionY: 1400, // vertical center of the caption block
  fs: 1.25, // font scale for beat graphics
} as const;
