// Inter = closest freely licensed match to SF Pro for Latin text.
// Bengali letters and digits fall through to Noto Sans Bengali.
import { loadFont as loadInter } from "@remotion/google-fonts/Inter";
import { loadFont as loadBengali } from "@remotion/google-fonts/NotoSansBengali";

const latin = loadInter("normal", { weights: ["500", "700", "800"], subsets: ["latin"] });
const bengali = loadBengali("normal", { weights: ["600", "800"], subsets: ["bengali"] });

export const FONT_STACK = `"${latin.fontFamily}", "${bengali.fontFamily}", sans-serif`;
