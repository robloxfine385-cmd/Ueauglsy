// ─────────────────────────────────────────────────────────────────────────────
// SCRIPT + BEAT TIMELINE  (the only file you edit)
//
// RAW_SCRIPT : one spoken sentence per entry, in order. Timing is derived automatically:
//              proportional to text length, snapped to the real pauses measured in the
//              reference audio (PAUSES). Override any line by giving it explicit times in MANUAL_LINES.
// BEATS      : motion-graphic moments (seconds). Types: hook | keyword | stat | list | cta.
// ─────────────────────────────────────────────────────────────────────────────
import { autoSync } from "./autoSync";
import type { Line } from "./autoSync";

export type Beat =
  | { type: "hook"; start: number; end: number; title: string; sub?: string; highlight?: number }
  | { type: "keyword"; start: number; end: number; word: string; label?: string }
  | {
      type: "stat";
      start: number;
      end: number;
      value: number;
      label: string;
      prefix?: string;
      suffix?: string;
      decimals?: number;
      fill?: number;
      numerals?: "bn" | "en";
    }
  | { type: "list"; start: number; end: number; title?: string; items: string[] }
  | { type: "cta"; start: number; end: number; title: string; button: string };

// Pause midpoints (seconds) measured from the reference audio. Speech ran 0.15s → 71.25s in the reference audio.
export const PAUSES = [
  4.9, 7.4, 9.15, 13.43, 16.45, 19.63, 22.78, 24.1, 26.33, 27.95, 32.08, 34.03, 36.45, 39.33, 41.08,
  48.2, 49.93, 52.78, 54.78, 57.18, 60.55, 62.03, 65.7, 67.28, 70.38,
];

export const RAW_SCRIPT: string[] = [
  "লাইন ১ : এখানে আপনার স্ক্রিপ্টের প্রথম বাক্য",
  "লাইন ২ : এখানে আপনার স্ক্রিপ্টের দ্বিতীয় বাক্য",
  "লাইন ৩ : এখানে আপনার স্ক্রিপ্টের তৃতীয় বাক্য",
  "লাইন ৪ : এখানে আপনার স্ক্রিপ্টের চতুর্থ বাক্য",
  "লাইন ৫ : এখানে আপনার স্ক্রিপ্টের পঞ্চম বাক্য",
  "লাইন ৬ : এখানে আপনার স্ক্রিপ্টের ষষ্ঠ বাক্য",
  "লাইন ৭ : এখানে আপনার স্ক্রিপ্টের সপ্তম বাক্য",
  "লাইন ৮ : এখানে আপনার স্ক্রিপ্টের অষ্টম বাক্য",
  "লাইন ৯ : এখানে আপনার স্ক্রিপ্টের নবম বাক্য",
  "লাইন ১০ : এখানে আপনার স্ক্রিপ্টের শেষ বাক্য",
];

// Set to an array of { start, end, text } (seconds) to bypass auto timing.
export const MANUAL_LINES: Line[] | null = null;

export const LINES: Line[] =
  MANUAL_LINES ?? autoSync(RAW_SCRIPT, { start: 0.15, end: 71.25, pauses: PAUSES });

export const BEATS: Beat[] = [
  { type: "hook", start: 0.3, end: 4.8, title: "আপনার হুক লাইন এখানে", sub: "সাবটাইটেল এখানে" },
  { type: "keyword", start: 7.45, end: 9.1, word: "মূল শব্দ", label: "কীওয়ার্ড" },
  { type: "stat", start: 13.5, end: 19.4, value: 87, suffix: "%", label: "আপনার স্ট্যাট এখানে", numerals: "bn" },
  {
    type: "list",
    start: 27.95,
    end: 36.3,
    title: "৩টি পয়েন্ট",
    items: ["পয়েন্ট ১", "পয়েন্ট ২", "পয়েন্ট ৩"],
  },
  { type: "keyword", start: 41.1, end: 47.9, word: "দ্বিতীয় শব্দ", label: "মনে রাখুন" },
  { type: "cta", start: 65.7, end: 71.25, title: "আরও জানতে", button: "ফলো করুন" },
];
